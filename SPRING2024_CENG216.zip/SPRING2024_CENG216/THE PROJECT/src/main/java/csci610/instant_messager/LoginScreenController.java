package csci610.instant_messager;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginScreenController {


    @FXML
    private TextField UsernameBar;
    @FXML
    private PasswordField PasswordBar;
    @FXML
    private Button loginButton;
   
    @FXML
    private void InitializeConnection(ActionEvent event) {
    }

}
