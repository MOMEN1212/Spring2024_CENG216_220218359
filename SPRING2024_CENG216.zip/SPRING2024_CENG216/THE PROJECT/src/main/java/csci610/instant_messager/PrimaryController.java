package csci610.instant_messager;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

public class PrimaryController {

    @FXML
    private Button SendButton;
    @FXML
    private ListView<?> chatview;

    @FXML
    private void sendMessageToServer(ActionEvent event) {
        
        
    }
}
